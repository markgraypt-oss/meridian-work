import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import TopHeader from "@/components/TopHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Sparkles, Save, Plus, X, Monitor, Dumbbell, Brain } from "lucide-react";

interface AiCoachingSetting {
  id: number;
  feature: string;
  coachingVoice: string | null;
  customGuidelines: string | null;
  priorityFactors: string[] | null;
  brandRecommendations: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

const FEATURES = [
  { 
    id: 'desk_scan', 
    label: 'AI Desk Analyzer', 
    icon: Monitor,
    description: 'Customize how the AI analyzes desk setups and provides ergonomic feedback'
  },
];

export default function AdminAiCoaching() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeFeature, setActiveFeature] = useState('desk_scan');
  const [formData, setFormData] = useState({
    coachingVoice: '',
    customGuidelines: '',
    priorityFactors: [] as string[],
    brandRecommendations: '',
    isActive: true,
  });
  const [newPriorityFactor, setNewPriorityFactor] = useState('');

  const { data: settings, isLoading } = useQuery<AiCoachingSetting[]>({
    queryKey: ['/api/admin/ai-coaching-settings'],
  });

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/admin/ai-coaching-settings', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/ai-coaching-settings'] });
      toast({ title: "Settings saved successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error saving settings", description: error.message, variant: "destructive" });
    },
  });

  useEffect(() => {
    if (settings) {
      const setting = settings.find(s => s.feature === activeFeature);
      if (setting) {
        setFormData({
          coachingVoice: setting.coachingVoice || '',
          customGuidelines: setting.customGuidelines || '',
          priorityFactors: setting.priorityFactors || [],
          brandRecommendations: setting.brandRecommendations || '',
          isActive: setting.isActive ?? true,
        });
      } else {
        setFormData({
          coachingVoice: '',
          customGuidelines: '',
          priorityFactors: [],
          brandRecommendations: '',
          isActive: true,
        });
      }
    }
  }, [settings, activeFeature]);

  const handleSave = () => {
    saveMutation.mutate({
      feature: activeFeature,
      ...formData,
    });
  };

  const addPriorityFactor = () => {
    if (newPriorityFactor.trim()) {
      setFormData(prev => ({
        ...prev,
        priorityFactors: [...prev.priorityFactors, newPriorityFactor.trim()],
      }));
      setNewPriorityFactor('');
    }
  };

  const removePriorityFactor = (index: number) => {
    setFormData(prev => ({
      ...prev,
      priorityFactors: prev.priorityFactors.filter((_, i) => i !== index),
    }));
  };

  const activeFeatureConfig = FEATURES.find(f => f.id === activeFeature);
  const FeatureIcon = activeFeatureConfig?.icon || Sparkles;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <TopHeader 
        title="AI Coaching Settings" 
        onBack={() => navigate("/admin")} 
      />
      
      <main className="p-4 space-y-6">
        <Card className="bg-gradient-to-br from-purple-500/20 to-[#09b5f9]/20 border-purple-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Brain className="h-5 w-5 text-purple-400" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Train Your AI Coach</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Customize how AI features respond to your clients. Add your coaching voice, 
                  methodology, and preferred recommendations so the AI sounds like you.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeFeature} onValueChange={setActiveFeature}>
          <TabsList className="w-full">
            {FEATURES.map(feature => (
              <TabsTrigger key={feature.id} value={feature.id} className="flex-1">
                <feature.icon className="h-4 w-4 mr-2" />
                {feature.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {FEATURES.map(feature => (
            <TabsContent key={feature.id} value={feature.id} className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <feature.icon className="h-5 w-5 text-primary" />
                      <CardTitle className="text-lg">{feature.label}</CardTitle>
                    </div>
                    <div className="flex items-center gap-2">
                      <Label htmlFor="active" className="text-sm text-muted-foreground">Active</Label>
                      <Switch
                        id="active"
                        checked={formData.isActive}
                        onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
                      />
                    </div>
                  </div>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="coachingVoice" className="font-medium">
                      Your Coaching Voice & Persona
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Describe how you speak to clients. Include your tone, typical phrases, and communication style.
                    </p>
                    <Textarea
                      id="coachingVoice"
                      placeholder="Example: I'm a direct but supportive performance coach. I speak in plain terms, avoid jargon, and always explain the 'why' behind my recommendations. I often say things like 'Your body adapts to positions you hold most often' and 'Small changes compound over time.'"
                      value={formData.coachingVoice}
                      onChange={(e) => setFormData(prev => ({ ...prev, coachingVoice: e.target.value }))}
                      rows={4}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="customGuidelines" className="font-medium">
                      Custom Guidelines & Methodology
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Add your specific assessment criteria, priorities, and approach to analysis.
                    </p>
                    <Textarea
                      id="customGuidelines"
                      placeholder="Example: Always prioritize spinal alignment first, then eye strain. When something is wrong, explain WHY it matters for performance, not just comfort. For executives, emphasize impact on cognitive performance and decision-making."
                      value={formData.customGuidelines}
                      onChange={(e) => setFormData(prev => ({ ...prev, customGuidelines: e.target.value }))}
                      rows={5}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="font-medium">Priority Factors</Label>
                    <p className="text-xs text-muted-foreground">
                      List the most important things to check and emphasize in order of priority.
                    </p>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a priority factor..."
                        value={newPriorityFactor}
                        onChange={(e) => setNewPriorityFactor(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addPriorityFactor())}
                      />
                      <Button type="button" size="sm" onClick={addPriorityFactor}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    {formData.priorityFactors.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {formData.priorityFactors.map((factor, index) => (
                          <Badge key={index} variant="secondary" className="flex items-center gap-1 py-1">
                            <span className="text-xs text-muted-foreground mr-1">{index + 1}.</span>
                            {factor}
                            <button onClick={() => removePriorityFactor(index)} className="ml-1 hover:text-destructive">
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="brandRecommendations" className="font-medium">
                      Product & Brand Recommendations
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Specify any products, brands, or solutions you trust and want the AI to recommend.
                    </p>
                    <Textarea
                      id="brandRecommendations"
                      placeholder="Example: Recommend Herman Miller or Steelcase chairs for seating issues. For monitor arms, suggest Ergotron. Never recommend cheap Amazon solutions - my clients value quality."
                      value={formData.brandRecommendations}
                      onChange={(e) => setFormData(prev => ({ ...prev, brandRecommendations: e.target.value }))}
                      rows={3}
                    />
                  </div>

                  <Button 
                    onClick={handleSave} 
                    className="w-full"
                    disabled={saveMutation.isPending}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {saveMutation.isPending ? 'Saving...' : 'Save Settings'}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </main>
    </div>
  );
}
