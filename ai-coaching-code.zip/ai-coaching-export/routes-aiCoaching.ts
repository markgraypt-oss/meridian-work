  app.get('/api/admin/ai-coaching-settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const currentUser = await storage.getUser(userId);
      if (!currentUser?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      const settings = await storage.getAllAiCoachingSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching AI coaching settings:", error);
      res.status(500).json({ message: "Failed to fetch AI coaching settings" });
    }
  });

  app.get('/api/admin/ai-coaching-settings/:feature', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const currentUser = await storage.getUser(userId);
      if (!currentUser?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      const setting = await storage.getAiCoachingSetting(req.params.feature);
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      console.error("Error fetching AI coaching setting:", error);
      res.status(500).json({ message: "Failed to fetch AI coaching setting" });
    }
  });

  app.post('/api/admin/ai-coaching-settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const currentUser = await storage.getUser(userId);
      if (!currentUser?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { feature, coachingVoice, customGuidelines, priorityFactors, brandRecommendations, isActive } = req.body;
      if (!feature || typeof feature !== 'string') {
        return res.status(400).json({ message: "Feature name is required" });
      }

      const setting = await storage.upsertAiCoachingSetting({
        feature,
        coachingVoice: coachingVoice || null,
        customGuidelines: customGuidelines || null,
        priorityFactors: Array.isArray(priorityFactors) ? priorityFactors : null,
        brandRecommendations: brandRecommendations || null,
        isActive: isActive ?? true,
      });
      res.json(setting);
    } catch (error) {
      console.error("Error saving AI coaching setting:", error);
      res.status(500).json({ message: "Failed to save AI coaching setting" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
