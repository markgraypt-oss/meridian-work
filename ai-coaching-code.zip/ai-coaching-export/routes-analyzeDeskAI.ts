  app.post('/api/workday/analyze-desk', isAuthenticated, async (req: any, res) => {
    try {
      const { imageBase64, deskType, positionType } = req.body;
      
      if (!imageBase64) {
        return res.status(400).json({ message: "Image is required" });
      }

      // Fetch custom coaching guidelines if configured
      const coachingSettings = await storage.getAiCoachingSetting('desk_scan');
      
      const Anthropic = (await import('@anthropic-ai/sdk')).default;
      const anthropic = new Anthropic({
        apiKey: process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY,
        baseURL: process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL,
      });

      const mediaType = imageBase64.startsWith('data:image/png') ? 'image/png' : 'image/jpeg';
      const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');

      // Build the prompt with custom coaching guidelines
      let coachingContext = '';
      if (coachingSettings && coachingSettings.isActive) {
        if (coachingSettings.coachingVoice) {
          coachingContext += `\n\nIMPORTANT COACHING STYLE:\n${coachingSettings.coachingVoice}\n`;
        }
        if (coachingSettings.customGuidelines) {
          coachingContext += `\nCUSTOM GUIDELINES TO FOLLOW:\n${coachingSettings.customGuidelines}\n`;
        }
        if (coachingSettings.priorityFactors && coachingSettings.priorityFactors.length > 0) {
          coachingContext += `\nPRIORITY FACTORS TO EMPHASIZE:\n${coachingSettings.priorityFactors.join('\n')}\n`;
        }
        if (coachingSettings.brandRecommendations) {
          coachingContext += `\nPRODUCT/BRAND RECOMMENDATIONS:\n${coachingSettings.brandRecommendations}\n`;
        }
      }

      const message = await anthropic.messages.create({
        model: "claude-sonnet-4-5",
        max_tokens: 2048,
        messages: [
          {
            role: "user",
            content: [
              {
                type: "image",
                source: {
                  type: "base64",
                  media_type: mediaType,
                  data: base64Data,
                },
              },
              {
                type: "text",
                text: `You are an expert ergonomics consultant analyzing a ${positionType || 'seated'} desk setup. Analyze this workspace image and provide specific, actionable feedback.${coachingContext}

Please evaluate and provide feedback on:
1. **Monitor Position** - Height, distance, and angle (eyes should be level with top third of screen, arm's length away)
2. **Chair Setup** - Height, back support, armrest position (if visible)
3. **Keyboard & Mouse** - Position, height, wrist alignment (elbows at 90°, wrists neutral)
4. **Lighting** - Glare, ambient lighting, screen brightness
5. **Posture Indicators** - Any visible posture concerns based on the setup
6. **Desk Organization** - Clutter, frequently used items within reach

For each issue found, provide:
- What's wrong
- Why it matters for health/productivity
- How to fix it

End with a summary score (1-10) and top 3 priority fixes.

Format your response as JSON with this structure:
{
  "score": number,
  "summary": "brief overall assessment",
  "issues": [
    {
      "category": "category name",
      "status": "good" | "needs_improvement" | "critical",
      "observation": "what you see",
      "recommendation": "how to fix it"
    }
  ],
  "priorityFixes": ["fix 1", "fix 2", "fix 3"]
}`
              }
            ],
          }
        ],
      });

      const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
      
      let analysis;
      try {
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          analysis = JSON.parse(jsonMatch[0]);
        } else {
          analysis = { rawResponse: responseText };
        }
      } catch {
        analysis = { rawResponse: responseText };
      }

      const userId = req.user.claims.sub;
      const observations = analysis.issues?.map((i: any) => `${i.category}: ${i.observation}`) || [];
      
      const scan = await storage.createWorkdayDeskScan({
        userId,
        deskType: deskType || 'standard',
        positionType: positionType || 'seated',
        observations,
      });

      res.json({ 
        scanId: scan.id,
        analysis 
      });
    } catch (error) {
      console.error("Error analyzing desk setup:", error);
      res.status(500).json({ message: "Failed to analyze desk setup" });
