export const aiCoachingSettings = pgTable("ai_coaching_settings", {
  id: serial("id").primaryKey(),
  feature: text("feature").notNull().unique(), // 'desk_scan', 'workout_coach', etc.
  coachingVoice: text("coaching_voice"), // Overall tone and persona
  customGuidelines: text("custom_guidelines"), // Main instructions
  priorityFactors: text("priority_factors").array(), // What to emphasize
  brandRecommendations: text("brand_recommendations"), // Products to suggest
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type AiCoachingSetting = typeof aiCoachingSettings.$inferSelect;
export type InsertAiCoachingSetting = typeof aiCoachingSettings.$inferInsert;
export const insertAiCoachingSettingSchema = createInsertSchema(aiCoachingSettings).omit({ id: true, createdAt: true, updatedAt: true });

// Chat models for AI conversations
export * from "./models/chat";
