import { useState, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import TopHeader from "@/components/TopHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Camera, 
  Upload, 
  Loader2, 
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Sparkles,
  Monitor,
  Armchair,
  ArrowUpDown,
  History,
  Check,
  ImageIcon
} from "lucide-react";
import type { WorkdayDeskScan } from "@shared/schema";

type PositionType = "seated" | "standing" | "alternative";

interface AnalysisIssue {
  category: string;
  status: "good" | "needs_improvement" | "critical";
  observation: string;
  recommendation: string;
}

interface AnalysisResult {
  score: number;
  summary: string;
  issues: AnalysisIssue[];
  priorityFixes: string[];
  rawResponse?: string;
}

function StatusIcon({ status }: { status: string }) {
  switch (status) {
    case "good":
      return <CheckCircle2 className="h-5 w-5 text-green-500" />;
    case "needs_improvement":
      return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
    case "critical":
      return <XCircle className="h-5 w-5 text-red-500" />;
    default:
      return <AlertTriangle className="h-5 w-5 text-gray-500" />;
  }
}

function ScoreCircle({ score }: { score: number }) {
  const getColor = () => {
    if (score >= 8) return "text-green-500";
    if (score >= 5) return "text-yellow-500";
    return "text-red-500";
  };

  return (
    <div className="flex flex-col items-center">
      <div className={`text-5xl font-bold ${getColor()}`}>{score}</div>
      <div className="text-sm text-muted-foreground">out of 10</div>
    </div>
  );
}

export default function WorkdayDeskScan() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  
  const [positionType, setPositionType] = useState<PositionType>("seated");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [showPhotoTips, setShowPhotoTips] = useState(false);
  const [pendingAction, setPendingAction] = useState<"camera" | "upload" | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: scanHistory, isLoading: historyLoading } = useQuery<WorkdayDeskScan[]>({
    queryKey: ['/api/workday/scans'],
    enabled: isAuthenticated,
  });

  const analyzeMutation = useMutation({
    mutationFn: async (data: { imageBase64: string; positionType: string }): Promise<{ scanId: number; analysis: AnalysisResult }> => {
      const response = await apiRequest('POST', '/api/workday/analyze-desk', data);
      return response.json();
    },
    onSuccess: (data: { scanId: number; analysis: AnalysisResult }) => {
      setAnalysis(data.analysis);
      queryClient.invalidateQueries({ queryKey: ['/api/workday/scans'] });
      toast({ 
        title: "Analysis complete!", 
        description: `Your desk scored ${data.analysis.score || 'N/A'}/10` 
      });
    },
    onError: () => {
      toast({ 
        title: "Analysis failed", 
        description: "Please try again with a clearer image",
        variant: "destructive"
      });
    }
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setImagePreview(base64);
        setAnalysis(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = () => {
    if (!imagePreview) {
      toast({ title: "Please upload an image first", variant: "destructive" });
      return;
    }
    analyzeMutation.mutate({ imageBase64: imagePreview, positionType });
  };

  const handleUploadClick = (action: "camera" | "upload") => {
    setPendingAction(action);
    setShowPhotoTips(true);
  };

  const handleProceedWithPhoto = () => {
    setShowPhotoTips(false);
    if (fileInputRef.current && pendingAction) {
      if (pendingAction === "camera") {
        fileInputRef.current.setAttribute('capture', 'environment');
      } else {
        fileInputRef.current.removeAttribute('capture');
      }
      fileInputRef.current.click();
    }
    setPendingAction(null);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#09b5f9]" />
      </div>
    );
  }

  if (!isAuthenticated) {
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <TopHeader 
        title="AI Desk Analyzer" 
        onBack={() => navigate("/recovery/desk-health")} 
      />
      
      <main className="p-4 space-y-6">
        <Card className="bg-gradient-to-br from-[#09b5f9]/20 to-[#09b5f9]/5 border-[#09b5f9]/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-2">
              <Sparkles className="h-5 w-5 text-[#09b5f9]" />
              <h2 className="font-semibold text-[#09b5f9]">AI-Powered Analysis</h2>
            </div>
            <p className="text-sm text-foreground/80">
              Upload a photo of your desk setup and our AI will analyze your ergonomics, 
              providing personalized recommendations to reduce pain and improve productivity.
            </p>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <h3 className="font-medium text-foreground">Select Your Position</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { type: "seated" as PositionType, label: "Seated", icon: Armchair },
              { type: "standing" as PositionType, label: "Standing", icon: ArrowUpDown },
              { type: "alternative" as PositionType, label: "Other", icon: Monitor },
            ].map(({ type, label, icon: Icon }) => (
              <button
                key={type}
                onClick={() => setPositionType(type)}
                className={`p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all ${
                  positionType === type
                    ? "border-[#09b5f9] bg-[#09b5f9]/10"
                    : "border-border bg-card hover:border-gray-600"
                }`}
              >
                <Icon className={`h-6 w-6 ${positionType === type ? "text-[#09b5f9]" : "text-muted-foreground"}`} />
                <span className={`text-sm ${positionType === type ? "text-foreground" : "text-muted-foreground"}`}>
                  {label}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileSelect}
              className="hidden"
            />
            
            {imagePreview ? (
              <div className="space-y-4">
                <div className="relative rounded-xl overflow-hidden">
                  <img 
                    src={imagePreview} 
                    alt="Desk preview" 
                    className="w-full h-64 object-cover"
                  />
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => {
                      setImagePreview(null);
                      setAnalysis(null);
                    }}
                    className="absolute top-3 right-3"
                  >
                    Change
                  </Button>
                </div>
                <Button
                  onClick={handleAnalyze}
                  disabled={analyzeMutation.isPending}
                  className="w-full bg-[#09b5f9] hover:bg-[#09b5f9]/80 text-white"
                >
                  {analyzeMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Analyze My Setup
                    </>
                  )}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="border-2 border-dashed border-gray-600 rounded-xl p-6 text-center">
                  <div className="flex flex-col items-center gap-3 mb-4">
                    <div className="p-4 rounded-full bg-[#09b5f9]/10">
                      <Camera className="h-8 w-8 text-[#09b5f9]" />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Capture your full desk setup including monitor, chair, and keyboard
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1 border-[#09b5f9] text-[#09b5f9] hover:bg-[#09b5f9]/10"
                      onClick={() => handleUploadClick("upload")}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Choose File
                    </Button>
                    <Button
                      className="flex-1 bg-[#09b5f9] hover:bg-[#09b5f9]/80 text-white"
                      onClick={() => handleUploadClick("camera")}
                    >
                      <Camera className="h-4 w-4 mr-2" />
                      Take Photo
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {analysis && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground text-lg">Your Score</h3>
                  <ScoreCircle score={analysis.score || 0} />
                </div>
                <p className="text-foreground/80">{analysis.summary}</p>
              </CardContent>
            </Card>

            {analysis.priorityFixes && analysis.priorityFixes.length > 0 && (
              <Card className="bg-red-500/10 border-red-500/30">
                <CardContent className="p-4">
                  <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-400" />
                    Priority Fixes
                  </h3>
                  <div className="space-y-2">
                    {analysis.priorityFixes.map((fix, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-500/20 text-red-400 text-sm flex items-center justify-center">
                          {index + 1}
                        </span>
                        <span className="text-foreground/80">{fix}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {analysis.issues && analysis.issues.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold text-foreground">Detailed Analysis</h3>
                {analysis.issues.map((issue, index) => (
                  <Card key={index} className="bg-card border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-2">
                        <StatusIcon status={issue.status} />
                        <span className="font-medium text-foreground">{issue.category}</span>
                        <Badge 
                          variant="outline" 
                          className={`ml-auto capitalize ${
                            issue.status === "good" 
                              ? "border-green-500 text-green-500"
                              : issue.status === "critical"
                              ? "border-red-500 text-red-500"
                              : "border-yellow-500 text-yellow-500"
                          }`}
                        >
                          {issue.status.replace("_", " ")}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground text-sm mb-2">{issue.observation}</p>
                      {issue.status !== "good" && (
                        <div className="bg-muted rounded-lg p-3 mt-2">
                          <p className="text-sm text-[#09b5f9]">
                            <strong>Fix:</strong> {issue.recommendation}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {analysis.rawResponse && !analysis.issues && (
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <h3 className="font-semibold text-foreground mb-3">Analysis</h3>
                  <p className="text-foreground/80 whitespace-pre-wrap">{analysis.rawResponse}</p>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {scanHistory && scanHistory.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <History className="h-5 w-5 text-muted-foreground" />
              <h3 className="font-medium text-foreground">Previous Scans</h3>
            </div>
            <div className="space-y-2">
              {scanHistory.slice(0, 5).map((scan) => (
                <Card key={scan.id} className="bg-card border-border">
                  <CardContent className="p-3 flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-muted">
                      {scan.positionType === "standing" ? (
                        <ArrowUpDown className="h-4 w-4 text-[#09b5f9]" />
                      ) : (
                        <Armchair className="h-4 w-4 text-[#09b5f9]" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-foreground capitalize">{scan.positionType} Setup</p>
                      <p className="text-xs text-muted-foreground">
                        {scan.scanDate ? new Date(scan.scanDate).toLocaleDateString() : 'Unknown date'}
                      </p>
                    </div>
                    {scan.observations && scan.observations.length > 0 && (
                      <Badge variant="outline" className="text-muted-foreground">
                        {scan.observations.length} issues
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </main>

      <Dialog open={showPhotoTips} onOpenChange={setShowPhotoTips}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-foreground flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-[#09b5f9]" />
              Photo Tips
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-gray-800 rounded-xl p-8 flex items-center justify-center border-2 border-dashed border-gray-600">
              <div className="text-center">
                <Monitor className="h-16 w-16 text-gray-500 mx-auto mb-2" />
                <p className="text-sm text-gray-500">Example image placeholder</p>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-foreground">For the best analysis, include:</h4>
              <ul className="space-y-2">
                {[
                  "Your monitor at its normal position",
                  "Keyboard and mouse visible",
                  "Your chair (back and armrests)",
                  "Overall desk layout clearly framed",
                  "Good lighting (avoid glare)"
                ].map((tip, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-foreground/80">
                    <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-amber-100 border border-amber-300 rounded-lg p-3">
              <p className="text-sm text-amber-800">
                <strong>Tip:</strong> Stand back 3-4 feet to capture your entire setup in frame.
              </p>
            </div>

            <Button 
              className="w-full bg-[#09b5f9] hover:bg-[#09b5f9]/80 text-white"
              onClick={handleProceedWithPhoto}
            >
              {pendingAction === "camera" ? (
                <>
                  <Camera className="h-4 w-4 mr-2" />
                  Open Camera
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Choose File
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
